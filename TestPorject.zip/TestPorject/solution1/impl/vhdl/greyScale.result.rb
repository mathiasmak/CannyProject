$Footmark = "FPGA_Xilinx"
$Description = "by Vivado"


#=== Resource usage ===
$SLICE = "0"
$LUT = "1767"
$FF = "1918"
$DSP = "25"
$BRAM ="4"
$SRL ="30"
#=== Final timing ===
$TargetCP = "10.000"
$CP = "8.764"
